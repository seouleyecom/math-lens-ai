# 수학 렌즈 AI — 안드로이드 프로젝트

## 현재 포함 기능
- CameraX 후면 카메라 미리보기 및 실시간 프레임 분석
- Google ML Kit 한국어 텍스트 인식
- 인식 결과 표시
- 간단한 사칙연산 문자열 계산기

## 중요한 제한
이 프로젝트는 실제 앱의 시작용 소스 코드입니다. 현재 AI 서버는 연결되어 있지 않으며, 문장제/도형/분수 풀이 및 생성형 AI 설명은 아직 제공하지 않습니다. 기본 계산기는 인식된 사칙연산 식만 처리하며 OCR 오류가 있을 수 있으므로 답을 검산해야 합니다.

## PC 없이 APK 만들기 (GitHub 모바일 웹)
1. GitHub 계정에 로그인하고 새 저장소(repository)를 만듭니다. 이름 예: `math-lens-ai`
2. 이 ZIP의 압축을 풀고 파일/폴더를 저장소에 업로드합니다. GitHub 웹에서 `Add file` → `Upload files`를 사용합니다.
3. 저장소의 `Actions` 탭을 엽니다.
4. `Build Math Lens AI APK` 워크플로를 선택하고 `Run workflow`를 누릅니다.
5. 빌드가 끝나면 완료된 실행 기록을 열고 아래 `Artifacts`에서 `math-lens-ai-debug-apk`를 다운로드합니다.
6. ZIP으로 받은 artifact를 풀어 `app-debug.apk`를 휴대폰에 다운로드하고 실행합니다.
7. Android가 설치를 막으면 안내에 따라 해당 브라우저/파일 앱에 대해 '이 출처의 앱 설치 허용'을 켭니다. 설치 후 카메라 권한을 허용합니다.

## 빌드 전 필수 보완 사항
워크플로가 GitHub Actions 안에서 Gradle 8.9를 설치하고 Gradle Wrapper를 생성한 뒤 APK를 빌드하므로, PC에서 wrapper를 미리 만들 필요가 없습니다.

## AI 서버 연결
실제 생성형 AI 풀이를 위해서는 별도 HTTPS 백엔드가 필요합니다. API 키를 APK 안에 넣지 마세요. 앱에서 인식 텍스트를 백엔드로 전송하고, 백엔드가 AI 공급자 API를 호출해 JSON 형태로 풀이를 반환하도록 연결해야 합니다.
