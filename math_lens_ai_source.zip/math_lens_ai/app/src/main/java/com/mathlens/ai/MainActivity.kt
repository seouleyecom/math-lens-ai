package com.mathlens.ai

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) recreate()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permission.launch(Manifest.permission.CAMERA)
        }
        setContent { MathLensScreen() }
    }
}

@Composable
fun MathLensScreen() {
    val context = LocalContext.current
    var recognized by remember { mutableStateOf("카메라에 수학 문제를 비춰보세요.") }
    var lastSolve by remember { mutableStateOf("문제가 인식되면 계산 가능한 식을 찾아 풀이합니다.") }
    var cameraReady by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF2563EB), background = Color(0xFFF5F8FC))) {
        Column(Modifier.fillMaxSize().background(Color(0xFFF5F8FC)).verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("수학 렌즈 AI", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color(0xFF173B69))
            Text("카메라로 비추면 수학 문제를 읽어드려요", color = Color.Gray, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))
            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF102B4C))) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CameraAlt, null, tint = Color.White)
                        Spacer(Modifier.width(8.dp))
                        Text("실시간 문제 스캔", color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text(if (cameraReady) "● 작동 중" else "카메라 준비", color = Color(0xFFB9E7C5), fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    CameraPreview(
                        onText = { text ->
                            if (text.isNotBlank()) {
                                recognized = text
                                lastSolve = solveBasicMath(text)
                            }
                        },
                        onReady = { cameraReady = it }
                    )
                    Text("문제를 화면 가운데에 맞추고 잠시 기다려 주세요.", color = Color(0xFFD7E6F7), fontSize = 12.sp, modifier = Modifier.padding(top = 9.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("인식한 문제", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(recognized, color = Color(0xFF24364B), lineHeight = 23.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF4FF))) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Calculate, null, tint = Color(0xFF2563EB))
                        Spacer(Modifier.width(8.dp))
                        Text("풀이 결과", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF173B69))
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(lastSolve, color = Color(0xFF24364B), lineHeight = 24.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lightbulb, null, tint = Color(0xFFD28B00))
                Spacer(Modifier.width(6.dp))
                Text("현재 기본 계산은 사칙연산 식에 한정됩니다. 문장제·도형·분수 풀이에는 AI 서버 연결이 필요합니다.", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}

@Composable
fun CameraPreview(onText: (String) -> Unit, onReady: (Boolean) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context).apply { scaleType = PreviewView.ScaleType.FILL_CENTER } }
    val executor = remember { Executors.newSingleThreadExecutor() }
    val busy = remember { AtomicBoolean(false) }

    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxWidth().height(330.dp).background(Color.Black))
    DisposableEffect(Unit) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        val listener = Runnable {
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor) { proxy ->
                    if (!busy.compareAndSet(false, true)) { proxy.close(); return@setAnalyzer }
                    val media = proxy.image
                    if (media == null) {
                        proxy.close(); busy.set(false)
                    } else {
                        val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                        recognizer.process(input)
                            .addOnSuccessListener { result ->
                                val value = result.text.trim()
                                if (value.length >= 3) onText(value)
                            }
                            .addOnCompleteListener {
                                proxy.close()
                                busy.set(false)
                            }
                    }
                }
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                onReady(true)
            } catch (_: Exception) { onReady(false) }
        }
        providerFuture.addListener(listener, ContextCompat.getMainExecutor(context))
        onDispose {
            try { ProcessCameraProvider.getInstance(context).get().unbindAll() } catch (_: Exception) {}
            executor.shutdown()
            onReady(false)
        }
    }
}

fun solveBasicMath(raw: String): String {
    val normalized = raw.replace("×", "*").replace("÷", "/").replace("−", "-")
        .replace(",", "").replace(" ", "").replace("＝", "=")
    val candidate = Regex("""(?<![\d.])[-+]?\d+(?:\.\d+)?(?:[+\-*/][-+]?\d+(?:\.\d+)?){1,}""")
        .find(normalized)?.value
    if (candidate == null) return "숫자 계산식을 아직 찾지 못했어요.\n문제를 더 가까이 비추거나, 문장제·분수·도형 문제는 AI 풀이 기능 연결이 필요합니다."
    return try {
        val result = ExpressionParser(candidate).parse()
        "인식한 식: $candidate\n\n계산 결과: ${if (result % 1.0 == 0.0) result.toLong().toString() else result.toString()}\n\n풀이 안내: 연산 순서에 따라 괄호와 곱셈·나눗셈을 먼저 계산하고, 덧셈·뺄셈을 계산했습니다."
    } catch (_: Exception) {
        "식은 인식했지만 계산하지 못했어요. 숫자와 기호가 선명하게 보이도록 다시 비춰주세요."
    }
}

class ExpressionParser(private val s: String) {
    private var i = 0
    fun parse(): Double {
        val v = expression()
        if (i != s.length) error("unexpected")
        return v
    }
    private fun expression(): Double {
        var v = term()
        while (i < s.length && (s[i] == '+' || s[i] == '-')) {
            val op = s[i++]; val r = term()
            v = if (op == '+') v + r else v - r
        }
        return v
    }
    private fun term(): Double {
        var v = factor()
        while (i < s.length && (s[i] == '*' || s[i] == '/')) {
            val op = s[i++]; val r = factor()
            v = if (op == '*') v * r else v / r
        }
        return v
    }
    private fun factor(): Double {
        val start = i
        if (i < s.length && (s[i] == '+' || s[i] == '-')) i++
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        if (start == i) error("number expected")
        return s.substring(start, i).toDouble()
    }
}
